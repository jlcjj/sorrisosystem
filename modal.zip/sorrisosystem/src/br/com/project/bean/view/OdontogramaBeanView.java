package br.com.project.bean.view;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.el.ELResolver;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.bean.geral.BeanManagedViewAbstract;
import br.com.project.carregamento.lazy.CarregamentoLazyListForObject;
import br.com.project.geral.controller.OdontogramaController;
import br.com.project.listener.dentesView;
import br.com.project.model.classes.Atendimento;
import br.com.project.model.classes.Odontograma;

@Controller
@Scope(value="session")
@ManagedBean(name = "odontogramaBeanView")
public class OdontogramaBeanView extends BeanManagedViewAbstract {

	/**
	 * 
	 */
	@ManagedProperty(value = "#{atendimentoBeanView}")
	private AtendimentoBeanView atendimentoBeanView;
	
	private static final long serialVersionUID = 1L;

	private String url = "/cadastro/cad_odontograma.jsf?faces-redirect=true";
	private String urlFind = "/cadastro/find_atendimento.jsf?faces-redirect=true";
	
	private Odontograma objetoSelecionado = new Odontograma();
	
	private CarregamentoLazyListForObject<Odontograma> list = new CarregamentoLazyListForObject<Odontograma>();
	//private List<Procedimentos> list = new ArrayList<Procedimentos>();
	
	/*@Override
	public StreamedContent getArquivoReport() throws Exception {
		super.setNomeRelatorioJasper("report_procedimentos");
		super.setNomeRelatorioSaida("report_procedimentos");
		super.setListDataBeanCollectionReport(odontogramaController.findList(getClassImplement()));
		return super.getArquivoReport();
	}	*/
	
	
	public CarregamentoLazyListForObject<Odontograma> getList() throws Exception {
		//list = procedimentosController.findList(getClassImplement());
		return list;
	}

	
	
	protected Class<Odontograma> getClassImplement() {
		return Odontograma.class;

	}

	public void abrirDialogo(String dente)
	{

		dentesView d = new dentesView();
		d.escolha(dente);
		String desc = d.getDescricao();
		
		String numDente = desc.substring(0, 2);
		
		objetoSelecionado.setDescricao_dente(desc);
	     objetoSelecionado.setDente(numDente);
	    
		
		Map<String, Object> opcoes =  new HashMap<String, Object>();
		
		

	    /* objetoSelecionado.getDescricao_dente();
	     objetoSelecionado.getDente();
	     
		objetoSelecionado.setDescricao_dente(desc);
	     objetoSelecionado.setDente(numDente);*/
	     
		
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 700);
		opcoes.put("contentWidth", 900);
		
		
		
		 Map<String, List<String>> params = new HashMap<>();
		  params.put("meuParametro", Arrays.asList(""+desc)); 
		
		
		
		RequestContext.getCurrentInstance().openDialog("cad_odontograma_proc", opcoes, params);

		
	
	}
	
	public String saveParameters(Long atendimento, String usuario, String objeto) throws Exception {
		String numDente = objeto.substring(0, 2);
		
		
		
		
		list.clean();
	    
	     objetoSelecionado.getAtendimento().setAtendimento_id(atendimento);   
	     objetoSelecionado.setDentista(usuario);
		
	     objetoSelecionado.setDescricao_dente(objeto);
	     objetoSelecionado.setDente(numDente);
	     
			objetoSelecionado = odontogramaController.merge(objetoSelecionado);
			list.add(objetoSelecionado);
			//objetoSelecionado = new Odontograma();
			
			sucesso();
			
		return "";
	}
	@Override
	public String save() throws Exception {
		FacesContext ctx = FacesContext.getCurrentInstance();
	    Map sessionMap = ctx.getExternalContext().getSessionMap();

	    AtendimentoBeanView mbean = (AtendimentoBeanView) sessionMap.get("AtendimentoBeanView");
	    
	     objetoSelecionado.getAtendimento().getAtendimento_id()  ;
		//System.out.println(objetoSelecionado.getNomeMedico());
			objetoSelecionado = odontogramaController.merge(objetoSelecionado);
			novo();
		return "";
	}
	
	
	@Override
	public void saveEdit() throws Exception {
		// TODO Auto-generated method stub
		saveNotReturn();
	}
	@Override
	public void saveNotReturn() throws Exception {
		list.clean();
		objetoSelecionado = odontogramaController.merge(objetoSelecionado);
		list.add(objetoSelecionado);
		objetoSelecionado = new Odontograma();
		sucesso();
	}
		
	@Override
	public String novo() throws Exception {
		setarVariaveisNulas();
		return url;
	}
	
	@Override
	public void setarVariaveisNulas() throws Exception {
		list.clean();
		objetoSelecionado = new Odontograma();
	}
	
	@Override
	public String editar() throws Exception {
		list.clean();
		return url;
	}

	@Override
	public void excluir() throws Exception {
		// TODO Auto-generated method stub
		objetoSelecionado = (Odontograma) odontogramaController.getSession()
				.get(getClassImplement(), objetoSelecionado.getOdontograma_id());
		odontogramaController.delete(objetoSelecionado);
		list.remove(objetoSelecionado);
		novo();
		sucesso();
	}
	
	@Autowired
	private OdontogramaController odontogramaController;

	public Odontograma getObjetoSelecionado() {
		return objetoSelecionado;
	}

	public void setObjetoSelecionado(Odontograma objetoSelecionado) {
		this.objetoSelecionado = objetoSelecionado;
	}
	public List<SelectItem> getOdontograma() throws Exception{
		return odontogramaController.getListOdontograma();
	}
	
	@Override
	public String redirecionarFindEntidade() throws Exception {
		setarVariaveisNulas();
		return urlFind;
	}
	
	@Override
	protected InterfaceCrud<Odontograma> getController() {
	
		return odontogramaController;
	}
	
	@Override
	public void consultarEntidade() throws Exception {
		objetoSelecionado = new Odontograma();
		list.clean();
		list.setTotalRegistroConsulta(super.totalRegistroConsulta(), super.SqlLazyQuery());
	}


	@Override
	public String condicaoAndParaPesquisa() throws Exception {
		// TODO Auto-generated method stub
		return "";
	}


	@Override
	public void saveNotReturnHorario() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
