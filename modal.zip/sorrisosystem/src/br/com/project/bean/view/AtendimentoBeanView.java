package br.com.project.bean.view;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;

import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.bean.geral.BeanManagedViewAbstract;
import br.com.project.carregamento.lazy.CarregamentoLazyListForObject;
import br.com.project.geral.controller.AtendimentoController;
import br.com.project.model.classes.Atendimento;

@Controller
@Scope(value="session")
@ManagedBean(name = "atendimentoBeanView")
public class AtendimentoBeanView extends BeanManagedViewAbstract {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url = "/cadastro/cad_odontograma.jsf?faces-redirect=true";
	private String urlFind = "/cadastro/find_atendimento.jsf?faces-redirect=true";
	
	private Atendimento objetoSelecionado = new Atendimento();
	
	private CarregamentoLazyListForObject<Atendimento> list = new CarregamentoLazyListForObject<Atendimento>();
	//private List<atendimento> list = new ArrayList<atendimento>();
	
	/*@Override
	public StreamedContent getArquivoReport() throws Exception {
		super.setNomeRelatorioJasper("report_atendimento");
		super.setNomeRelatorioSaida("report_atendimento");
		super.setListDataBeanCollectionReport(atendimentoController.findList(getClassImplement()));
		return super.getArquivoReport();
	}	*/
	
	
	public CarregamentoLazyListForObject<Atendimento> getList() throws Exception {
		//list = atendimentoController.findList(getClassImplement());
		return list;
	}

	
	
	protected Class<Atendimento> getClassImplement() {
		return Atendimento.class;

	}

	

	@Override
	public String save() throws Exception {
		//System.out.println(objetoSelecionado.getNomeMedico());
			objetoSelecionado = atendimentoController.merge(objetoSelecionado);
			//novo();
			sucesso();
		return "";
	}
	
	
	@Override
	public void saveEdit() throws Exception {
		// TODO Auto-generated method stub
		saveNotReturn();
	}
	@Override
	public void saveNotReturn() throws Exception {
		list.clean();
		objetoSelecionado = atendimentoController.merge(objetoSelecionado);
		list.add(objetoSelecionado);
		objetoSelecionado = new Atendimento();
		sucesso();
	}
		
	@Override
	public String novo() throws Exception {
		setarVariaveisNulas();
		return url;
	}
	
	@Override
	public void setarVariaveisNulas() throws Exception {
		list.clean();
		objetoSelecionado = new Atendimento();
	}
	
	@Override
	public String editar() throws Exception {
		list.clean();
		return url;
	}

	@Override
	public void excluir() throws Exception {
		// TODO Auto-generated method stub
		objetoSelecionado = (Atendimento) atendimentoController.getSession()
				.get(getClassImplement(), objetoSelecionado.getAtendimento_id());
		atendimentoController.delete(objetoSelecionado);
		list.remove(objetoSelecionado);
		novo();
		sucesso();
	}
	
	@Autowired
	private AtendimentoController atendimentoController;

	public Atendimento getObjetoSelecionado() {
		return objetoSelecionado;
	}

	public void setObjetoSelecionado(Atendimento objetoSelecionado) {
		this.objetoSelecionado = objetoSelecionado;
	}
	public List<SelectItem> getatendimento() throws Exception{
		return atendimentoController.getListAtendimento();
	}
	
	@Override
	public String redirecionarFindEntidade() throws Exception {
		setarVariaveisNulas();
		return urlFind;
	}
	
	@Override
	protected InterfaceCrud<Atendimento> getController() {
	
		return atendimentoController;
	}
	
	@Override
	public void consultarEntidade() throws Exception {
		objetoSelecionado = new Atendimento();
		list.clean();
		list.setTotalRegistroConsulta(super.totalRegistroConsulta(), super.SqlLazyQuery());
	}


	@Override
	public String condicaoAndParaPesquisa() throws Exception {
		// TODO Auto-generated method stub
		return "";
	}


	@Override
	public void saveNotReturnHorario() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
