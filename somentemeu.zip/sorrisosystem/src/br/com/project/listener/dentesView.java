package br.com.project.listener;

import javax.faces.bean.ManagedBean;

import org.springframework.context.annotation.Scope;

import br.com.project.bean.view.OdontogramaBeanView;


@Scope(value = "session")
@ManagedBean(name = "dentesView")
public class dentesView {
	private boolean d11=false;
	private boolean d12=false;
	private boolean d13=false;
	private boolean d14=false;
	private boolean d15=false;
	private boolean d16=false;
	private boolean d17=false;
	private boolean d18=false;	
	
	private boolean d21=false;
	private boolean d22=false;
	private boolean d23=false;
	private boolean d24=false;
	private boolean d25=false;
	private boolean d26=false;
	private boolean d27=false;
	private boolean d28=false;
	
	private boolean d31=false;
	private boolean d32=false;
	private boolean d33=false;
	private boolean d34=false;
	private boolean d35=false;
	private boolean d36=false;
	private boolean d37=false;
	private boolean d38=false;	
	
	private boolean d41=false;
	private boolean d42=false;
	private boolean d43=false;
	private boolean d44=false;
	private boolean d45=false;
	private boolean d46=false;
	private boolean d47=false;
	private boolean d48=false;
	
	
	private boolean d51=false;
	private boolean d52=false;
	private boolean d53=false;
	private boolean d54=false;
	private boolean d55=false;
	
	private boolean d61=false;
	private boolean d62=false;
	private boolean d63=false;
	private boolean d64=false;
	private boolean d65=false;
	
	private boolean d71=false;
	private boolean d72=false;
	private boolean d73=false;
	private boolean d74=false;
	private boolean d75=false;
	
	private boolean d81=false;
	private boolean d82=false;
	private boolean d83=false;
	private boolean d84=false;
	private boolean d85=false;
	
	private String descricao = "";
	


	public boolean isD18() {
		return d18;
	}

	public void setD18(boolean d18) {
		this.d18 = d18;
	}

	public boolean isD17() {
		return d17;
	}

	public void setD17(boolean d17) {
		this.d17 = d17;
	}

	public boolean isD11() {
		return d11;
	}

	public void setD11(boolean d11) {
		this.d11 = d11;
	}

	public boolean isD12() {
		return d12;
	}

	public void setD12(boolean d12) {
		this.d12 = d12;
	}

	public boolean isD13() {
		return d13;
	}

	public void setD13(boolean d13) {
		this.d13 = d13;
	}

	public boolean isD14() {
		return d14;
	}

	public void setD14(boolean d14) {
		this.d14 = d14;
	}

	public boolean isD15() {
		return d15;
	}

	public void setD15(boolean d15) {
		this.d15 = d15;
	}

	public boolean isD16() {
		return d16;
	}

	public void setD16(boolean d16) {
		this.d16 = d16;
	}

	public boolean isD21() {
		return d21;
	}

	public void setD21(boolean d21) {
		this.d21 = d21;
	}

	public boolean isD22() {
		return d22;
	}

	public void setD22(boolean d22) {
		this.d22 = d22;
	}

	public boolean isD23() {
		return d23;
	}

	public void setD23(boolean d23) {
		this.d23 = d23;
	}

	public boolean isD24() {
		return d24;
	}

	public void setD24(boolean d24) {
		this.d24 = d24;
	}

	public boolean isD25() {
		return d25;
	}

	public void setD25(boolean d25) {
		this.d25 = d25;
	}

	public boolean isD26() {
		return d26;
	}

	public void setD26(boolean d26) {
		this.d26 = d26;
	}

	public boolean isD27() {
		return d27;
	}

	public void setD27(boolean d27) {
		this.d27 = d27;
	}

	public boolean isD28() {
		return d28;
	}

	public void setD28(boolean d28) {
		this.d28 = d28;
	}

	public boolean isD31() {
		return d31;
	}

	public void setD31(boolean d31) {
		this.d31 = d31;
	}

	public boolean isD32() {
		return d32;
	}

	public void setD32(boolean d32) {
		this.d32 = d32;
	}

	public boolean isD33() {
		return d33;
	}

	public void setD33(boolean d33) {
		this.d33 = d33;
	}

	public boolean isD34() {
		return d34;
	}

	public void setD34(boolean d34) {
		this.d34 = d34;
	}

	public boolean isD35() {
		return d35;
	}

	public void setD35(boolean d35) {
		this.d35 = d35;
	}

	public boolean isD36() {
		return d36;
	}

	public void setD36(boolean d36) {
		this.d36 = d36;
	}

	public boolean isD37() {
		return d37;
	}

	public void setD37(boolean d37) {
		this.d37 = d37;
	}

	public boolean isD38() {
		return d38;
	}

	public void setD38(boolean d38) {
		this.d38 = d38;
	}

	public boolean isD41() {
		return d41;
	}

	public void setD41(boolean d41) {
		this.d41 = d41;
	}

	public boolean isD42() {
		return d42;
	}

	public void setD42(boolean d42) {
		this.d42 = d42;
	}

	public boolean isD43() {
		return d43;
	}

	public void setD43(boolean d43) {
		this.d43 = d43;
	}

	public boolean isD44() {
		return d44;
	}

	public void setD44(boolean d44) {
		this.d44 = d44;
	}

	public boolean isD45() {
		return d45;
	}

	public void setD45(boolean d45) {
		this.d45 = d45;
	}

	public boolean isD46() {
		return d46;
	}

	public void setD46(boolean d46) {
		this.d46 = d46;
	}

	public boolean isD47() {
		return d47;
	}

	public void setD47(boolean d47) {
		this.d47 = d47;
	}

	public boolean isD48() {
		return d48;
	}

	public void setD48(boolean d48) {
		this.d48 = d48;
	}

	public boolean isD51() {
		return d51;
	}

	public void setD51(boolean d51) {
		this.d51 = d51;
	}

	public boolean isD52() {
		return d52;
	}

	public void setD52(boolean d52) {
		this.d52 = d52;
	}

	public boolean isD53() {
		return d53;
	}

	public void setD53(boolean d53) {
		this.d53 = d53;
	}

	public boolean isD54() {
		return d54;
	}

	public void setD54(boolean d54) {
		this.d54 = d54;
	}

	public boolean isD55() {
		return d55;
	}

	public void setD55(boolean d55) {
		this.d55 = d55;
	}

	public boolean isD61() {
		return d61;
	}

	public void setD61(boolean d61) {
		this.d61 = d61;
	}

	public boolean isD62() {
		return d62;
	}

	public void setD62(boolean d62) {
		this.d62 = d62;
	}

	public boolean isD63() {
		return d63;
	}

	public void setD63(boolean d63) {
		this.d63 = d63;
	}

	public boolean isD64() {
		return d64;
	}

	public void setD64(boolean d64) {
		this.d64 = d64;
	}

	public boolean isD65() {
		return d65;
	}

	public void setD65(boolean d65) {
		this.d65 = d65;
	}

	public boolean isD71() {
		return d71;
	}

	public void setD71(boolean d71) {
		this.d71 = d71;
	}

	public boolean isD72() {
		return d72;
	}

	public void setD72(boolean d72) {
		this.d72 = d72;
	}

	public boolean isD73() {
		return d73;
	}

	public void setD73(boolean d73) {
		this.d73 = d73;
	}

	public boolean isD74() {
		return d74;
	}

	public void setD74(boolean d74) {
		this.d74 = d74;
	}

	public boolean isD75() {
		return d75;
	}

	public void setD75(boolean d75) {
		this.d75 = d75;
	}

	public boolean isD81() {
		return d81;
	}

	public void setD81(boolean d81) {
		this.d81 = d81;
	}

	public boolean isD82() {
		return d82;
	}

	public void setD82(boolean d82) {
		this.d82 = d82;
	}

	public boolean isD83() {
		return d83;
	}

	public void setD83(boolean d83) {
		this.d83 = d83;
	}

	public boolean isD84() {
		return d84;
	}

	public void setD84(boolean d84) {
		this.d84 = d84;
	}

	public boolean isD85() {
		return d85;
	}

	public void setD85(boolean d85) {
		this.d85 = d85;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}	
	OdontogramaBeanView ob = new OdontogramaBeanView();
	public void escolha(String dente) {
		if (dente.equals("d18")) {
			
			descricao ="18 - Terceiro molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d17")) {
			descricao ="17 - Segundo molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d16")) {
			descricao ="16 - Primeiro molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d15")) {
			descricao ="15 - Segundo pr� molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d14")) {
			descricao ="14 - Primeiro pr� molar superior direito ";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d13")) {
			descricao ="13 - Canino superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("d12")) {
			descricao ="12 - Incisivo lateral superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("11")) {
			descricao ="11 - Incisivo central superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("28")) {
			descricao ="28 - Terceiro molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("27")) {
			descricao ="27 - Segundo molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("26")) {
			descricao ="26 - Primeiro molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("25")) {
			descricao ="25 - Segundo pr� molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("24")) {
			descricao ="24 - Primeiro pr� molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("23")) {
			descricao ="23 - Canino superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("22")) {
			descricao ="22 - Incisivo lateral superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("21")) {
			descricao ="21 - Incisivo central superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("38")) {
			descricao ="38 - Terceiro molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("37")) {
			descricao ="37 - Segundo molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("36")) {
			descricao ="36 - Primeiro molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("35")) {
			descricao ="35 - Segundo pr� molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("34")) {
			descricao ="34 - Primeiro pr� molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("33")) {
			descricao ="33 - Canino inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("32")) {
			descricao ="32 - Incisivo lateral inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("31")) {
			descricao ="31 - Incisivo central inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("48")) {
			descricao ="48 - Terceiro molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("47")) {
			descricao ="47 - Segundo molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("46")) {
			descricao ="46 - Primeiro molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("45")) {
			descricao ="45 - Segundo pr� molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("44")) {
			descricao ="44 - Primeiro pr� molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("43")) {
			descricao ="43 - Canino inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("42")) {
			descricao ="42 - Incisivo lateral inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("41")) {
			descricao ="41 - Incisivo central inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("55")) {
			descricao ="55 - Segundo molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("54")) {
			descricao ="54 - Primeiro molar superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("53")) {
			descricao ="53 - Canino superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("52")) {
			descricao ="52 - Incisivo lateral superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("51")) {
			descricao ="51 - Incisivo central superior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("65")) {
			descricao ="65 - Segundo molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("64")) {
			descricao ="64 - Primeiro molar superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("63")) {
			descricao ="63 - Canino superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("62")) {
			descricao ="62 - Incisivo lateral superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("61")) {
			descricao ="61 - Incisivo central superior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("75")) {
			descricao ="75 - Segundo molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("74")) {
			descricao ="74 - Primeiro molar inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("73")) {
			descricao ="73 - Canino inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("72")) {
			descricao ="72 - Incisivo lateral inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("71")) {
			descricao ="71 - Incisivo central inferior esquerdo";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("85")) {
			descricao ="85 - Segundo molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("84")) {
			descricao ="84 - Primeiro molar inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("83")) {
			descricao ="83 - Canino inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("82")) {
			descricao ="82 - Incisivo lateral inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}else if (dente.equals("81")) {
			descricao ="81 - Incisivo central inferior direito";
			ob.getObjetoSelecionado().setDescricao_dente(descricao);
		}
		
		
		
	}

	
	
}
