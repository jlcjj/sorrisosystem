package br.com.project.bean.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Controller;

import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.bean.geral.BeanManagedViewAbstract;
import br.com.project.carregamento.lazy.CarregamentoLazyListForObject;
import br.com.project.enums.CondicaoPesquisa;
import br.com.project.geral.controller.OdontogramaController;
import br.com.project.listener.dentesView;
import br.com.project.model.classes.Atendimento;
import br.com.project.model.classes.Odontograma;
import br.com.project.util.all.UtilitariaRegex;

@Controller
@Scope(value = "session")
@ManagedBean(name = "OdontogramaBeanView")
public class OdontogramaBeanView extends BeanManagedViewAbstract {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url = "/cadastro/cad_Odontogramas.jsf?faces-redirect=true";
	private String urlFind = "/cadastro/find_odontogramas.jsf?faces-redirect=true";

	private Odontograma objetoSelecionado = new Odontograma();

	private CarregamentoLazyListForObject<Odontograma> list = new CarregamentoLazyListForObject<Odontograma>();
	 private List<Odontograma> listao = new ArrayList<Odontograma>();

	String dente = "";
	String atende= "" ;
	
	@Override
	public StreamedContent getArquivoReport() throws Exception {
		super.setNomeRelatorioJasper("report_Odontogramas");
		super.setNomeRelatorioSaida("report_Odontogramas");
		super.setListDataBeanCollectionReport(odontogramaController.findList(getClassImplement()));
		return super.getArquivoReport();
	}

	public CarregamentoLazyListForObject<Odontograma> getList() throws Exception {
			
		
		// list = procedimentosController.findList(getClassImplement());
		return list;
	}
	
	public List<Odontograma> getListao() throws Exception {
		listao.clear();
		
		 List<Odontograma> listaodonto = new ArrayList<Odontograma> ();
		 Odontograma o = new Odontograma();
		
		String id = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		
		
		atende = id;
		
		
		List<Odontograma> odont = odontogramaController.findListByQueryDinamica(" from Odontograma " + getQueryConsultaI());
		
		
		/*String sql = (" select * from " + getQueryConsultaI()).toLowerCase();
		
		
	
		SqlRowSet sqlRowSet = getController().getJdbcTemplate().queryForRowSet(sql.toString());

		
		while (sqlRowSet.next()) {
			o.setDescricao_dente(sqlRowSet.getString(4));
			o.setObservacao(sqlRowSet.getString(6));
			o.setLocalDente(sqlRowSet.getString(5));
			o.setSituacao(sqlRowSet.getString(7));
			listaodonto.add(o);
		}

		
		
		
		listao = odontogramaController.findListByQueryDinamica(sql);*/
		
		
		return odont;
	}

	


	
	
	protected Class<Odontograma> getClassImplement() {
		return Odontograma.class;

	}

	
	public void abrirDialogo(String dente) throws Exception
	{

		dentesView d = new dentesView();
		d.escolha(dente);
		String desc = d.getDescricao();
		
		String numDente = desc.substring(0, 2);
			
		objetoSelecionado.setDescricao_dente(desc);
	     objetoSelecionado.setDente(numDente);
	    
	     
	  
		Map<String, Object> opcoes =  new HashMap<String, Object>();


	    /* objetoSelecionado.getDescricao_dente();
	     objetoSelecionado.getDente();
	     
		objetoSelecionado.setDescricao_dente(desc);
	     objetoSelecionado.setDente(numDente);*/
	     //atende = objetoSelecionado.getAtendimento().getAtendimento_id().toString();
		
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 700);
		opcoes.put("contentWidth", 900);
		
		
		
		 Map<String, List<String>> params = new HashMap<>();
		 
		  params.put("meuParametro", Arrays.asList(""+desc)); 
		  
		
		
		RequestContext.getCurrentInstance().openDialog("cad_odontograma_proc", opcoes, params);

		
	
	}
	
	public String saveParameters(Long atendimento, String usuario, String objeto) throws Exception {
		String numDente = objeto.substring(0, 2);
		
		list.clean();
	    
		
		
	     objetoSelecionado.getAtendimento().setAtendimento_id(atendimento);   
	     objetoSelecionado.setDentista(usuario);
		 objetoSelecionado.setDescricao_dente(objeto);
	     objetoSelecionado.setDente(numDente);
	     
			objetoSelecionado = odontogramaController.merge(objetoSelecionado);
			
			objetoSelecionado = new Odontograma();
			
			 objetoSelecionado.getAtendimento().setAtendimento_id(atendimento);   
			 
			 atende = objetoSelecionado.getAtendimento().getAtendimento_id().toString();
			 
			 
		     objetoSelecionado.setDentista(usuario);
		     objetoSelecionado.setDescricao_dente(objeto);
		     objetoSelecionado.setDente(numDente);
		     list.add(objetoSelecionado);
		     consultar();
		    
		     dente =numDente; 
			sucesso();
			
		return "";
	}
	
	@Override
	public String save() throws Exception {
		// System.out.println(objetoSelecionado.getNomeMedico());
		objetoSelecionado = odontogramaController.merge(objetoSelecionado);
		novo();
		return "";
	}

	@Override
	public void saveEdit() throws Exception {
		// TODO Auto-generated method stub
		saveNotReturn();
	}

	@Override
	public void saveNotReturn() throws Exception {
		list.clean();
		objetoSelecionado = odontogramaController.merge(objetoSelecionado);
		list.add(objetoSelecionado);
		objetoSelecionado = new Odontograma();
		sucesso();
	}

	@Override
	public String novo() throws Exception {
		setarVariaveisNulas();
		return url;
	}

	@Override
	public void setarVariaveisNulas() throws Exception {
		list.clean();
		objetoSelecionado = new Odontograma();
	}

	@Override
	public String editar() throws Exception {
		list.clean();
		return url;
	}

	@Override
	public void excluir() throws Exception {
		// TODO Auto-generated method stub
		objetoSelecionado = (Odontograma) odontogramaController.getSession().get(getClassImplement(),
				objetoSelecionado.getOdontograma_id());
		odontogramaController.delete(objetoSelecionado);
		list.remove(objetoSelecionado);
		novo();
		sucesso();
	}

	@Autowired
	private OdontogramaController odontogramaController;

	public Odontograma getObjetoSelecionado() {
		return objetoSelecionado;
	}

	public void setObjetoSelecionado(Odontograma objetoSelecionado) {
		this.objetoSelecionado = objetoSelecionado;
	}

	@Override
	public String redirecionarFindEntidade() throws Exception {
		setarVariaveisNulas();
		return urlFind;
	}

	@Override
	protected InterfaceCrud<Odontograma> getController() {

		return odontogramaController;
	}

	@Override
	public void consultarEntidade() throws Exception {

		objetoSelecionado = new Odontograma();
		list.clean();
		list.setTotalRegistroConsulta(totalRegistroConsulta(), SqlLazyQuery());
	}
	
	@SuppressWarnings("unchecked")
	public void consultar() throws Exception {

		objetoSelecionado = new Odontograma();
		listao.clear();
		list.setTotalRegistroConsulta(totalRegistroConsultaI(), SqlLazyQueryI());
		
	}
	
	
	public String SqlLazyQueryI() throws Exception {
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from ");
		sql.append(getQueryConsultaI());
		sql.append(" order by dente");
		
		return sql.toString();
	}

	
	private StringBuilder  getQueryConsultaI() throws Exception {
		
		StringBuilder sql = new StringBuilder();
		sql.append(getClassImplement().getSimpleName());

		sql.append(" ");
		sql.append(condicaoAndParaPesquisa());
		//return sql.toString();
		return sql;
	}

	protected int totalRegistroConsultaI() throws Exception {

		String sql = (" select count(1) from " + getQueryConsultaI()).toLowerCase();

		return getController().getJdbcTemplate().queryForInt(sql);

		}
	
	@Override
	public String condicaoAndParaPesquisa() throws Exception {
		// TODO Auto-generated method stub
		String id = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		
		
		atende = id;
		String retorno = "";
		if(dente =="" && atende != null)
		{retorno = " where atendimento = " + atende;
		}
		else if (atende != null && dente != "") 
		{
			retorno = " where atendimento = " + atende + " and dente = " + dente;
		}else
		{
			retorno = "";
		}
		return retorno ;
	}

	@Override
	public void saveNotReturnHorario() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
