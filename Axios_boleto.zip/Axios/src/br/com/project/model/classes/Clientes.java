package br.com.project.model.classes;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.envers.Audited;

import br.com.project.annotation.IdentificaCampoPesquisa;

@Audited
@Entity
@Table(name = "clientes")
public class Clientes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cliente_id;

	@IdentificaCampoPesquisa(descricaoCampo = "Nome", campoConsulta = "nome")
	@Column(nullable = false, length = 80)
	private String nome;

	@Column(nullable = true, length = 15)
	private String rg;
	
	@IdentificaCampoPesquisa(descricaoCampo = "CPF_CNPJ", campoConsulta = "cpf/CNPJ")
	@Column(nullable = false, length = 20)
	private String cpf_cnpj;

	@Column(nullable = false, length = 100)
	private String endereco;

	@Column(nullable = true, length = 8)
	private String numero;

	@Column(nullable = true, length = 80)
	private String complemento;

	@Column(nullable = true, length = 80)
	private String bairro;

	@Column(nullable = true, length = 10)
	private String cep;

	@Column(nullable = true, length = 80)
	private String cidade;

	@Column(nullable = true, length = 15)
	private String UF;

	@Column(nullable = true, length = 20)
	private String tel_fixo;

	@Column(nullable = true, length = 20)
	private String tel_celular;

	

	@Column(nullable = true, length = 15)
	private String data_nascimento;

	
	@Column(nullable = true, length = 200)
	private String observacao;

	@Column(nullable = true, length = 20)
	private String status;

	@Column(nullable = true, length = 15)
	private String Data_hora_cad;

	@Column(nullable = true, length = 20)
	private String usuario_cad;

	@Column(nullable = true, length = 20)
	private String Data_hora_alt;

	@Column(nullable = true, length = 20)
	private String usuario_alt;

	

	@Version
	@Column(name = "versionNum")
	private int versionNum;



	public Long getCliente_id() {
		return cliente_id;
	}



	public void setCliente_id(Long cliente_id) {
		this.cliente_id = cliente_id;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getRg() {
		return rg;
	}



	public void setRg(String rg) {
		this.rg = rg;
	}



	public String getCpf_cnpj() {
		return cpf_cnpj;
	}



	public void setCpf_cnpj(String cpf_cnpj) {
		this.cpf_cnpj = cpf_cnpj;
	}



	public String getEndereco() {
		return endereco;
	}



	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}



	public String getNumero() {
		return numero;
	}



	public void setNumero(String numero) {
		this.numero = numero;
	}



	public String getComplemento() {
		return complemento;
	}



	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}



	public String getBairro() {
		return bairro;
	}



	public void setBairro(String bairro) {
		this.bairro = bairro;
	}



	public String getCep() {
		return cep;
	}



	public void setCep(String cep) {
		this.cep = cep;
	}



	public String getCidade() {
		return cidade;
	}



	public void setCidade(String cidade) {
		this.cidade = cidade;
	}



	public String getUF() {
		return UF;
	}



	public void setUF(String uF) {
		UF = uF;
	}



	public String getTel_fixo() {
		return tel_fixo;
	}



	public void setTel_fixo(String tel_fixo) {
		this.tel_fixo = tel_fixo;
	}



	public String getTel_celular() {
		return tel_celular;
	}



	public void setTel_celular(String tel_celular) {
		this.tel_celular = tel_celular;
	}



	public String getData_nascimento() {
		return data_nascimento;
	}



	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}



	public String getObservacao() {
		return observacao;
	}



	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getData_hora_cad() {
		return Data_hora_cad;
	}



	public void setData_hora_cad(String data_hora_cad) {
		Data_hora_cad = data_hora_cad;
	}



	public String getUsuario_cad() {
		return usuario_cad;
	}



	public void setUsuario_cad(String usuario_cad) {
		this.usuario_cad = usuario_cad;
	}



	public String getData_hora_alt() {
		return Data_hora_alt;
	}



	public void setData_hora_alt(String data_hora_alt) {
		Data_hora_alt = data_hora_alt;
	}



	public String getUsuario_alt() {
		return usuario_alt;
	}



	public void setUsuario_alt(String usuario_alt) {
		this.usuario_alt = usuario_alt;
	}



	public int getVersionNum() {
		return versionNum;
	}



	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}



	@Override
	public String toString() {
		return "Clientes [cliente_id=" + cliente_id + ", nome=" + nome + ", rg=" + rg + ", cpf_cnpj=" + cpf_cnpj
				+ ", endereco=" + endereco + ", numero=" + numero + ", complemento=" + complemento + ", bairro="
				+ bairro + ", cep=" + cep + ", cidade=" + cidade + ", UF=" + UF + ", tel_fixo=" + tel_fixo
				+ ", tel_celular=" + tel_celular + ", data_nascimento=" + data_nascimento + ", observacao=" + observacao
				+ ", status=" + status + ", Data_hora_cad=" + Data_hora_cad + ", usuario_cad=" + usuario_cad
				+ ", Data_hora_alt=" + Data_hora_alt + ", usuario_alt=" + usuario_alt + ", versionNum=" + versionNum
				+ "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Data_hora_alt == null) ? 0 : Data_hora_alt.hashCode());
		result = prime * result + ((Data_hora_cad == null) ? 0 : Data_hora_cad.hashCode());
		result = prime * result + ((UF == null) ? 0 : UF.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((cliente_id == null) ? 0 : cliente_id.hashCode());
		result = prime * result + ((complemento == null) ? 0 : complemento.hashCode());
		result = prime * result + ((cpf_cnpj == null) ? 0 : cpf_cnpj.hashCode());
		result = prime * result + ((data_nascimento == null) ? 0 : data_nascimento.hashCode());
		result = prime * result + ((endereco == null) ? 0 : endereco.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + ((observacao == null) ? 0 : observacao.hashCode());
		result = prime * result + ((rg == null) ? 0 : rg.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((tel_celular == null) ? 0 : tel_celular.hashCode());
		result = prime * result + ((tel_fixo == null) ? 0 : tel_fixo.hashCode());
		result = prime * result + ((usuario_alt == null) ? 0 : usuario_alt.hashCode());
		result = prime * result + ((usuario_cad == null) ? 0 : usuario_cad.hashCode());
		result = prime * result + versionNum;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Clientes other = (Clientes) obj;
		if (Data_hora_alt == null) {
			if (other.Data_hora_alt != null)
				return false;
		} else if (!Data_hora_alt.equals(other.Data_hora_alt))
			return false;
		if (Data_hora_cad == null) {
			if (other.Data_hora_cad != null)
				return false;
		} else if (!Data_hora_cad.equals(other.Data_hora_cad))
			return false;
		if (UF == null) {
			if (other.UF != null)
				return false;
		} else if (!UF.equals(other.UF))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (cliente_id == null) {
			if (other.cliente_id != null)
				return false;
		} else if (!cliente_id.equals(other.cliente_id))
			return false;
		if (complemento == null) {
			if (other.complemento != null)
				return false;
		} else if (!complemento.equals(other.complemento))
			return false;
		if (cpf_cnpj == null) {
			if (other.cpf_cnpj != null)
				return false;
		} else if (!cpf_cnpj.equals(other.cpf_cnpj))
			return false;
		if (data_nascimento == null) {
			if (other.data_nascimento != null)
				return false;
		} else if (!data_nascimento.equals(other.data_nascimento))
			return false;
		if (endereco == null) {
			if (other.endereco != null)
				return false;
		} else if (!endereco.equals(other.endereco))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (observacao == null) {
			if (other.observacao != null)
				return false;
		} else if (!observacao.equals(other.observacao))
			return false;
		if (rg == null) {
			if (other.rg != null)
				return false;
		} else if (!rg.equals(other.rg))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (tel_celular == null) {
			if (other.tel_celular != null)
				return false;
		} else if (!tel_celular.equals(other.tel_celular))
			return false;
		if (tel_fixo == null) {
			if (other.tel_fixo != null)
				return false;
		} else if (!tel_fixo.equals(other.tel_fixo))
			return false;
		if (usuario_alt == null) {
			if (other.usuario_alt != null)
				return false;
		} else if (!usuario_alt.equals(other.usuario_alt))
			return false;
		if (usuario_cad == null) {
			if (other.usuario_cad != null)
				return false;
		} else if (!usuario_cad.equals(other.usuario_cad))
			return false;
		if (versionNum != other.versionNum)
			return false;
		return true;
	}

	

}
