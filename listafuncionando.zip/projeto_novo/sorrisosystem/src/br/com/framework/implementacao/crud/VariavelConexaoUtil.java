package br.com.framework.implementacao.crud;

public class VariavelConexaoUtil {
	public static String JAVA_COMP_ENV_JDBC_DATA_SOURCE = "com.mysql.jdbc.Driver";
	
}
