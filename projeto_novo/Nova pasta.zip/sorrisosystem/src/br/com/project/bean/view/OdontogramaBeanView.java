package br.com.project.bean.view;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;

import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.bean.geral.BeanManagedViewAbstract;
import br.com.project.carregamento.lazy.CarregamentoLazyListForObject;
import br.com.project.geral.controller.OdontogramaController;
import br.com.project.model.classes.Odontograma;

@Controller
@Scope(value="session")
@ManagedBean(name = "odontogramaBeanView")
public class OdontogramaBeanView extends BeanManagedViewAbstract {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url = "/cadastro/cad_odontograma.jsf?faces-redirect=true";
	private String urlFind = "/cadastro/find_atendimento.jsf?faces-redirect=true";
	
	private Odontograma objetoSelecionado = new Odontograma();
	
	private CarregamentoLazyListForObject<Odontograma> list = new CarregamentoLazyListForObject<Odontograma>();
	//private List<Procedimentos> list = new ArrayList<Procedimentos>();
	
	/*@Override
	public StreamedContent getArquivoReport() throws Exception {
		super.setNomeRelatorioJasper("report_procedimentos");
		super.setNomeRelatorioSaida("report_procedimentos");
		super.setListDataBeanCollectionReport(odontogramaController.findList(getClassImplement()));
		return super.getArquivoReport();
	}	*/
	
	
	public CarregamentoLazyListForObject<Odontograma> getList() throws Exception {
		//list = procedimentosController.findList(getClassImplement());
		return list;
	}

	
	
	protected Class<Odontograma> getClassImplement() {
		return Odontograma.class;

	}



	@Override
	public String save() throws Exception {
		//System.out.println(objetoSelecionado.getNomeMedico());
			objetoSelecionado = odontogramaController.merge(objetoSelecionado);
			novo();
		return "";
	}
	
	
	@Override
	public void saveEdit() throws Exception {
		// TODO Auto-generated method stub
		saveNotReturn();
	}
	@Override
	public void saveNotReturn() throws Exception {
		list.clean();
		objetoSelecionado = odontogramaController.merge(objetoSelecionado);
		list.add(objetoSelecionado);
		objetoSelecionado = new Odontograma();
		sucesso();
	}
		
	@Override
	public String novo() throws Exception {
		setarVariaveisNulas();
		return url;
	}
	
	@Override
	public void setarVariaveisNulas() throws Exception {
		list.clean();
		objetoSelecionado = new Odontograma();
	}
	
	@Override
	public String editar() throws Exception {
		list.clean();
		return url;
	}

	@Override
	public void excluir() throws Exception {
		// TODO Auto-generated method stub
		objetoSelecionado = (Odontograma) odontogramaController.getSession()
				.get(getClassImplement(), objetoSelecionado.getOdontograma_id());
		odontogramaController.delete(objetoSelecionado);
		list.remove(objetoSelecionado);
		novo();
		sucesso();
	}
	
	@Autowired
	private OdontogramaController odontogramaController;

	public Odontograma getObjetoSelecionado() {
		return objetoSelecionado;
	}

	public void setObjetoSelecionado(Odontograma objetoSelecionado) {
		this.objetoSelecionado = objetoSelecionado;
	}
	public List<SelectItem> getOdontograma() throws Exception{
		return odontogramaController.getListOdontograma();
	}
	
	@Override
	public String redirecionarFindEntidade() throws Exception {
		setarVariaveisNulas();
		return urlFind;
	}
	
	@Override
	protected InterfaceCrud<Odontograma> getController() {
	
		return odontogramaController;
	}
	
	@Override
	public void consultarEntidade() throws Exception {
		objetoSelecionado = new Odontograma();
		list.clean();
		list.setTotalRegistroConsulta(super.totalRegistroConsulta(), super.SqlLazyQuery());
	}


	@Override
	public String condicaoAndParaPesquisa() throws Exception {
		// TODO Auto-generated method stub
		return "";
	}


	@Override
	public void saveNotReturnHorario() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
