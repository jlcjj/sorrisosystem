package br.com.dao.implementacao;

import org.springframework.stereotype.Repository;

import br.com.framework.implementacao.crud.ImplementacaoCrud;
import br.com.project.model.classes.Odontograma;
import br.com.repository.interfaces.RepositoryOdontograma;

@Repository
public class DaoOdontograma extends ImplementacaoCrud<Odontograma> implements RepositoryOdontograma{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
