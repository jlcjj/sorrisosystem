package br.com.srv.implementacao;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.repository.interfaces.RepositoryClientes;
import br.com.srv.interfaces.SrvClientes;

@Service
public class SrvClientesImpl implements SrvClientes {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Resource
	private RepositoryClientes repositoryClientes;
}
