package br.com.project.geral.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.faces.model.SelectItem;

import org.springframework.stereotype.Controller;

import br.com.framework.implementacao.crud.ImplementacaoCrud;
import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.model.classes.Odontograma;
import br.com.repository.interfaces.RepositoryOdontograma;
import br.com.srv.interfaces.SrvOdontograma;

@Controller
public class OdontogramaController extends ImplementacaoCrud<Odontograma> implements InterfaceCrud<Odontograma> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Resource
	private SrvOdontograma srvOdontograma;
	
	@Resource
	private RepositoryOdontograma repositoryOdontograma;

	public List<SelectItem> getListOdontograma() throws Exception {
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		List<Odontograma> odont = super.findListByQueryDinamica(" from Odontograma");

		for (Odontograma odontograma : odont) {
			list.add(new SelectItem(odontograma, odontograma.getDescricao_dente()));
		}
		/*for (Procedimentos procedimentos : procedimento) {
			list.add(new SelectItem(procedimentos, procedimentos.getDescricao()));
		}*/
		return list;
	}
	
}
