package br.com.project.geral.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.faces.model.SelectItem;

import org.springframework.stereotype.Controller;

import br.com.framework.implementacao.crud.ImplementacaoCrud;
import br.com.framework.interfac.crud.InterfaceCrud;
import br.com.project.model.classes.Atendimento;
import br.com.repository.interfaces.RepositoryAtendimento;
import br.com.srv.interfaces.SrvAtendimento;

@Controller
public class AtendimentoController extends ImplementacaoCrud<Atendimento> implements InterfaceCrud<Atendimento> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Resource
	private SrvAtendimento srvAtendimento;
	
	@Resource
	private RepositoryAtendimento repositoryAtendimento;

	public List<SelectItem> getListAtendimento() throws Exception {
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		List<Atendimento> atend = super.findListByQueryDinamica(" from Atendimento");

		for (Atendimento atendimento : atend) {
			list.add(new SelectItem(atendimento, atendimento.getClientes().getNome()));
		}
		/*for (Procedimentos procedimentos : procedimento) {
			list.add(new SelectItem(procedimentos, procedimentos.getDescricao()));
		}*/
		return list;
	}
}
